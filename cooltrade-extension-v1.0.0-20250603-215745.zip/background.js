// Chrome Extension Background Script
// 处理 API 代理请求，统一使用 192.168.3.56:8000

const API_BASE_URL = 'http://192.168.3.56:8000';

// 监听来自前端的代理请求
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'PROXY_API_REQUEST') {
    handleProxyRequest(request.data)
      .then(response => {
        sendResponse({
          success: true,
          data: response.data,
          status: response.status,
          statusText: response.statusText
        });
      })
      .catch(error => {
        console.error('Proxy request failed:', error);
        sendResponse({
          success: false,
          error: error.message,
          errorDetail: error.detail || null
        });
      });
    
    // 返回 true 表示异步响应
    return true;
  }
  
  if (request.type === 'RELOAD_RESOURCES') {
    // 处理资源重新加载请求
    chrome.runtime.reload();
    return true;
  }
});

// 处理代理请求
async function handleProxyRequest(requestData) {
  const { url, method, headers, body } = requestData;
  
  // 构建完整的 URL
  let fullUrl;
  if (url.startsWith('/api')) {
    // 相对路径，添加基础 URL
    fullUrl = `${API_BASE_URL}${url}`;
  } else if (url.startsWith('http')) {
    // 绝对路径，检查是否需要替换域名
    if (url.includes('www.cooltrade.xyz')) {
      // 替换为本地服务器
      fullUrl = url.replace('https://www.cooltrade.xyz', API_BASE_URL);
    } else {
      fullUrl = url;
    }
  } else {
    // 其他情况，直接使用基础 URL
    fullUrl = `${API_BASE_URL}/api${url.startsWith('/') ? url : '/' + url}`;
  }
  
  console.log(`Proxying request: ${method} ${fullUrl}`);
  
  // 准备请求选项
  const fetchOptions = {
    method: method || 'GET',
    headers: {
      'Content-Type': 'application/json',
      ...headers
    }
  };
  
  // 添加请求体（如果有）
  if (body && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
    fetchOptions.body = typeof body === 'string' ? body : JSON.stringify(body);
  }
  
  try {
    const response = await fetch(fullUrl, fetchOptions);
    
    // 解析响应
    let responseData;
    const contentType = response.headers.get('content-type');
    
    if (contentType && contentType.includes('application/json')) {
      responseData = await response.json();
    } else {
      responseData = await response.text();
    }
    
    return {
      data: responseData,
      status: response.status,
      statusText: response.statusText
    };
  } catch (error) {
    console.error('Fetch error:', error);
    throw new Error(`Network request failed: ${error.message}`);
  }
}

// 扩展安装时的初始化
chrome.runtime.onInstalled.addListener(() => {
  console.log('CoolTrade Extension installed');
});

// 扩展启动时的初始化
chrome.runtime.onStartup.addListener(() => {
  console.log('CoolTrade Extension started');
});
